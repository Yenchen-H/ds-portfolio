"""
Array & Linked List — From-Scratch Implementation
==================================================
Implements:
  - DynamicArray   : resizable array with amortised O(1) append
  - SinglyLinkedList
  - DoublyLinkedList

No standard-library containers are used for the core logic.
"""

from __future__ import annotations
from typing import Any, Iterator, Optional


# ──────────────────────────────────────────────
# Dynamic Array
# ──────────────────────────────────────────────

class DynamicArray:
    """
    A resizable array that doubles capacity when full.

    Amortised analysis (potential method):
      Φ = 2 * size - capacity
      Each append costs O(1) amortised even though occasional
      copies cost O(n): the potential pays for the copy.
    """

    def __init__(self) -> None:
        self._capacity: int = 1
        self._size: int = 0
        self._data: list = [None] * self._capacity

    # ── core operations ──────────────────────

    def append(self, value: Any) -> None:
        """O(1) amortised."""
        if self._size == self._capacity:
            self._resize(self._capacity * 2)
        self._data[self._size] = value
        self._size += 1

    def get(self, index: int) -> Any:
        """O(1)."""
        self._check_index(index)
        return self._data[index]

    def set(self, index: int, value: Any) -> None:
        """O(1)."""
        self._check_index(index)
        self._data[index] = value

    def insert(self, index: int, value: Any) -> None:
        """O(n) — shifts elements right."""
        if index < 0 or index > self._size:
            raise IndexError("Index out of range")
        if self._size == self._capacity:
            self._resize(self._capacity * 2)
        for i in range(self._size, index, -1):
            self._data[i] = self._data[i - 1]
        self._data[index] = value
        self._size += 1

    def delete(self, index: int) -> Any:
        """O(n) — shifts elements left."""
        self._check_index(index)
        value = self._data[index]
        for i in range(index, self._size - 1):
            self._data[i] = self._data[i + 1]
        self._size -= 1
        # Shrink to avoid wasting memory (keeps load factor >= 0.25)
        if self._size > 0 and self._size == self._capacity // 4:
            self._resize(self._capacity // 2)
        return value

    # ── helpers ──────────────────────────────

    def _resize(self, new_capacity: int) -> None:
        new_data = [None] * new_capacity
        for i in range(self._size):
            new_data[i] = self._data[i]
        self._data = new_data
        self._capacity = new_capacity

    def _check_index(self, index: int) -> None:
        if index < 0 or index >= self._size:
            raise IndexError(f"Index {index} out of range for size {self._size}")

    def __len__(self) -> int:
        return self._size

    def __repr__(self) -> str:
        return f"DynamicArray({[self._data[i] for i in range(self._size)]})"


# ──────────────────────────────────────────────
# Singly Linked List
# ──────────────────────────────────────────────

class _SLLNode:
    __slots__ = ("val", "next")

    def __init__(self, val: Any) -> None:
        self.val = val
        self.next: Optional[_SLLNode] = None


class SinglyLinkedList:
    """
    Singly linked list with O(1) prepend and O(n) search.

    Memory layout: each node stores a value + one pointer.
    Unlike an array, there is no spatial locality — cache
    performance is generally worse despite same O complexity.
    """

    def __init__(self) -> None:
        self._head: Optional[_SLLNode] = None
        self._size: int = 0

    def prepend(self, val: Any) -> None:
        """O(1)."""
        node = _SLLNode(val)
        node.next = self._head
        self._head = node
        self._size += 1

    def append(self, val: Any) -> None:
        """O(n) — must traverse to tail."""
        node = _SLLNode(val)
        if not self._head:
            self._head = node
        else:
            cur = self._head
            while cur.next:
                cur = cur.next
            cur.next = node
        self._size += 1

    def delete_val(self, val: Any) -> bool:
        """O(n). Returns True if found and deleted."""
        dummy = _SLLNode(None)
        dummy.next = self._head
        prev, cur = dummy, self._head
        while cur:
            if cur.val == val:
                prev.next = cur.next
                self._head = dummy.next
                self._size -= 1
                return True
            prev, cur = cur, cur.next
        return False

    def reverse(self) -> None:
        """O(n) in-place reversal."""
        prev, cur = None, self._head
        while cur:
            nxt = cur.next
            cur.next = prev
            prev, cur = cur, nxt
        self._head = prev

    def has_cycle(self) -> bool:
        """Floyd's tortoise-and-hare — O(n) time, O(1) space."""
        slow = fast = self._head
        while fast and fast.next:
            slow = slow.next
            fast = fast.next.next
            if slow is fast:
                return True
        return False

    def __iter__(self) -> Iterator:
        cur = self._head
        while cur:
            yield cur.val
            cur = cur.next

    def __len__(self) -> int:
        return self._size

    def __repr__(self) -> str:
        return " -> ".join(str(v) for v in self) + " -> None"


# ──────────────────────────────────────────────
# Doubly Linked List
# ──────────────────────────────────────────────

class _DLLNode:
    __slots__ = ("val", "prev", "next")

    def __init__(self, val: Any) -> None:
        self.val = val
        self.prev: Optional[_DLLNode] = None
        self.next: Optional[_DLLNode] = None


class DoublyLinkedList:
    """
    Doubly linked list — O(1) insert/delete at both ends.
    Foundation for LRU Cache (combined with a hash map).
    """

    def __init__(self) -> None:
        # Sentinel nodes eliminate edge cases
        self._head = _DLLNode(None)   # dummy head
        self._tail = _DLLNode(None)   # dummy tail
        self._head.next = self._tail
        self._tail.prev = self._head
        self._size = 0

    def _insert_after(self, node: _DLLNode, val: Any) -> _DLLNode:
        """O(1). Insert new node directly after `node`."""
        new = _DLLNode(val)
        new.prev = node
        new.next = node.next
        node.next.prev = new
        node.next = new
        self._size += 1
        return new

    def _remove(self, node: _DLLNode) -> Any:
        """O(1). Remove a given node (must not be sentinel)."""
        node.prev.next = node.next
        node.next.prev = node.prev
        self._size -= 1
        return node.val

    def append_front(self, val: Any) -> _DLLNode:
        return self._insert_after(self._head, val)

    def append_back(self, val: Any) -> _DLLNode:
        return self._insert_after(self._tail.prev, val)

    def pop_front(self) -> Any:
        if self._size == 0:
            raise IndexError("pop from empty list")
        return self._remove(self._head.next)

    def pop_back(self) -> Any:
        if self._size == 0:
            raise IndexError("pop from empty list")
        return self._remove(self._tail.prev)

    def __len__(self) -> int:
        return self._size

    def __repr__(self) -> str:
        vals = []
        cur = self._head.next
        while cur is not self._tail:
            vals.append(str(cur.val))
            cur = cur.next
        return "None <-> " + " <-> ".join(vals) + " <-> None"


# ──────────────────────────────────────────────
# Quick smoke test
# ──────────────────────────────────────────────

if __name__ == "__main__":
    # DynamicArray
    da = DynamicArray()
    for i in range(8):
        da.append(i)
    print("DynamicArray:", da)
    da.insert(3, 99)
    print("After insert(3, 99):", da)
    da.delete(3)
    print("After delete(3):", da)

    # SinglyLinkedList
    sll = SinglyLinkedList()
    for v in [1, 2, 3, 4]:
        sll.append(v)
    print("\nSLL:", sll)
    sll.reverse()
    print("Reversed:", sll)
    print("Has cycle:", sll.has_cycle())

    # DoublyLinkedList
    dll = DoublyLinkedList()
    dll.append_back(10)
    dll.append_back(20)
    dll.append_front(5)
    print("\nDLL:", dll)
    print("pop_front:", dll.pop_front())
    print("pop_back:", dll.pop_back())
    print("DLL now:", dll)
